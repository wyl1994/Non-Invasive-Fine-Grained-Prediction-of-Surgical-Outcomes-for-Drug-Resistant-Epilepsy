clc;
clear;
close all;
%% load features matrix and labels
load('feature_nettopo.mat');

% sparsity autoencoder
% encoded_features_1 = sae(features_matrix, 30, 0.01, 0.1, 0.0001);
% encoded_features_2 = sae(features_matrix, 30, 0.01, 0.1, 0.0001);
% encoded_features_3 = sae(features_matrix, 30, 0.01, 0.1, 0.0001);
% encoded_features = [encoded_features_1,encoded_features_2,encoded_features_3];
%feature = encoded_features;

feature = features_matrix;

% Adjust the four-class labels to two classes
Engel_label(find(Engel_label~=1)) = 2;
label = Engel_label;

%% feature selection
n = 20;
rng(27);
index = randperm(length(feature));
feature = feature(index,:);
label = label(index,:);

% correlation based method
[r,p] = corr(feature,label);
[p_sort, idx] = sort(p,1); 
idx_select = idx(1:n);

% information gain based method
% idx_select = select_top_features(feature,label,20);

feature_select = feature(:,idx_select);

%% model training
k = 5;
rng(31)
num = size(feature_select,1);
u = rem(num,k);

% SVM
train_num = 0;
pre_train_SVM = [];
pre_SVM = [];
y_train = [];
y_test = [];
for i = 1:k
    if i <= u
        tmp(i) = ceil(num/k);
    else
        tmp(i) = floor(num/k);
    end
    test_data = feature_select(train_num + 1:train_num + tmp(i),:);
    train_data = [feature_select(1:train_num,:);...
        feature_select(train_num + tmp(i) + 1:num,:)];
    label_test = label(train_num + 1:train_num + tmp(i));
    y_test = [y_test;label_test];
    label_train = [label(1:train_num);label(train_num + tmp(i) + 1:num)];
    y_train = [y_train;label_train];
    SVMMODEL = fitcsvm(train_data,label_train,'OptimizeHyperparameters','auto','HyperparameterOptimizationOptions',struct('Optimizer','bayesopt'),'KernelFunction','gaussian');
    pre_train_SVM = [pre_train_SVM;predict(SVMMODEL,train_data)];
    pre = predict(SVMMODEL,test_data);
    pre_SVM = [pre_SVM;pre];
    correct_num_SVM(i) = sum((pre-label_test)==0);
    accuracy_svm(i) = correct_num_SVM(i) / length(label_test);
    train_num = train_num + tmp(i);
end
for i = 1:k
    fprintf("SVM Fold No.%d, correct number: %d, total: %d.\n", i, correct_num_SVM(i), tmp(i));
end
fprintf("svm average accuracy:%.4f ± %.4f\n",mean(accuracy_svm),std(accuracy_svm));
[CM_SVM_train,~] = confusionmat(y_train, pre_train_SVM);
fprintf("svm train:\n");
[acc_train_SVM, prec_train_SVM,sen_train_SVM,spe_train_SVM,f1_train_SVM]...
    = print_performance(CM_SVM_train);
[CM_SVM_test,~] = confusionmat(y_test, pre_SVM);
fprintf("svm validate:\n");
[acc_test_SVM, prec_test_SVM,sen_test_SVM,spe_test_SVM,f1_test_SVM]...
    = print_performance(CM_SVM_test);

% Random Forest
train_num = 0;
pre_train_RF = [];
pre_RF = [];
y_train = [];
y_test = [];
for i = 1:k
    if i <= u
        tmp(i) = ceil(num/k);
    else
        tmp(i) = floor(num/k);
    end
    test_data = feature_select(train_num + 1:train_num + tmp(i),:);
    train_data = [feature_select(1:train_num,:);...
        feature_select(train_num + tmp(i) + 1:num,:)];
    label_test = label(train_num + 1:train_num + tmp(i));
    y_test = [y_test;label_test];
    label_train = [label(1:train_num);label(train_num + tmp(i) + 1:num)];
    y_train = [y_train;label_train];
    nTree = 10;
    B = TreeBagger(nTree,train_data,label_train,'OOBPredictorImportance','on',...
        'Method', 'classification', 'OOBPrediction','on', 'minleaf', 3);
    predict_train_label = predict(B,train_data);
    predict_train_label = str2double(predict_train_label);
    pre_train_RF = [pre_train_RF;predict_train_label];
    predict_label = predict(B,test_data);
    predict_label = str2double(predict_label);
    pre_RF = [pre_RF;predict_label];
    correct_num_RF(i) = length(find(predict_label == label_test));
    accuracy_RF(i) = correct_num_RF(i)/length(label_test);
    fprintf("RF Fold No.%d, correct number: %d, total: %d.\n", i, correct_num_RF(i), tmp(i));
    train_num = train_num + tmp(i);
end
fprintf("RF average accuracy:%.4f ± %.4f\n",mean(accuracy_RF),std(accuracy_RF));
[CM_RF_train,~] = confusionmat(y_train, pre_train_RF);
fprintf("RF train:\n");
[acc_train_RF, prec_train_RF,sen_train_RF,spe_train_RF,f1_train_RF]...
    = print_performance(CM_RF_train);
[CM_RF_test,~] = confusionmat(y_test, pre_RF);
fprintf("RF validate:\n");
[acc_test_RF, prec_test_RF,sen_test_RF,spe_test_RF,f1_test_RF]...
    = print_performance(CM_RF_test);

% AdaBoost
correct_num_AB = [];
prediction_AB = [];
train_num = 0;
pre_train_AB = [];
y_train_AB= [];
y_test_AB = [];
for i = 1:k
    if i <= u
        tmp(i) = ceil(num/k);
    else
        tmp(i) = floor(num/k);
    end
    test_data = feature_select(train_num + 1:train_num + tmp(i),:);
    train_data = [feature_select(1:train_num,:);...
        feature_select(train_num + tmp(i) + 1:num,:)];
    label_test = label(train_num + 1:train_num + tmp(i));
    y_test_AB = [y_test_AB;label_test];
    label_train = [label(1:train_num);label(train_num + tmp(i) + 1:num)];
    y_train_AB = [y_train_AB;label_train];
    numTrees = 50;
    learners = ['discriminant'];
    method = 'AdaBoostM1';
    model = fitcensemble(train_data, label_train, ...
        'Method', method, 'NumLearningCycles', numTrees, ...
        'Learners', learners,'LearnRate',0.01);
    prediction_train_AB = predict(model,train_data);
    pre_train_AB = [pre_train_AB; prediction_train_AB];
    prediction_test_AB = predict(model, test_data);
    prediction_AB = [prediction_AB; prediction_test_AB];
    correct_num_AB(i) = sum( label_test == prediction_test_AB );
    accuracy_AB(i) = correct_num_AB(i)./ size(prediction_test_AB,1);
    fprintf("AdaBoost Fold No.%d, correct number： %d, total： %d.\n", i, correct_num_AB(i), tmp(i));
    train_num = train_num + tmp(i);
end
fprintf("AdaBoost average accuracy:%.4f ± %.4f\n",mean(accuracy_AB),std(accuracy_AB));
[CM_AB_train,~] = confusionmat(y_train_AB, pre_train_AB);
fprintf("AdaBoost train:\n");
[acc_train_AB, prec_train_AB,sen_train_AB,spe_train_AB,f1_train_AB]...
    = print_performance(CM_AB_train);
[CM_AB_test,~] = confusionmat(y_test_AB, prediction_AB);
fprintf("AdaBoost validate:\n");
[acc_test_AB, prec_test_AB,sen_test_AB,spe_test_AB,f1_test_AB]...
    = print_performance(CM_AB_test);

function [acc,pre,sen,spe,f1] = print_performance(CM)
    TP = CM(1,1);
    FP = CM(1,2);
    FN = CM(2,1);
    TN = CM(2,2);
    acc = (TP+TN)/sum(sum(CM));
    pre = TP/(TP + FP);%ppv
    sen = TP/(TP + FN);
    spe = TN/(FP + TN);
    npv = TN/(FN + TN);%npv
    f1 = 2*(pre*sen)/(pre+sen);
    fprintf("Acc: %f , precision(ppv): %f , sensitivity: %f, specificity: %f,NPV：%f，F1-score: %f\n",...
    acc,pre,sen,spe,npv,f1);
end

function info_gain = calculate_information_gain(features_matrix, labels)
    % Number of samples
    m = size(features_matrix, 1);
    % Number of features
    n = size(features_matrix, 2);
    
    % Normalize the features to the range [0, 1]
    normalized_features = normalize_features(features_matrix);
    
    % Calculate entropy of the entire dataset
    H_T = entropy(labels);
    
    info_gain = zeros(1, n);
    
    % Define the number of bins for the interval [0,1]
    num_bins = 10;
    
    for i = 1:n
        % Bin the feature values into intervals
        edges = linspace(0, 1, num_bins + 1);
        [~, ~, bin_indices] = histcounts(normalized_features(:, i), edges);
        
        H_Tv = 0;
        
        for j = 1:num_bins
            % Get the subset of labels for the current bin
            subset_indices = (bin_indices == j);
            subset_labels = labels(subset_indices);
            
            if ~isempty(subset_labels)
                % Calculate the entropy of the subset
                H_Tv = H_Tv + (sum(subset_indices) / m) * entropy(subset_labels);
            end
        end
        
        % Calculate information gain
        info_gain(i) = H_T - H_Tv;
    end
end

% Normalize features to the range [0, 1]
function normalized_features = normalize_features(features_matrix)
    min_values = min(features_matrix);
    max_values = max(features_matrix);
    range_values = max_values - min_values;
    
    % Handle cases where all values in a column are the same
    range_values(range_values == 0) = 1;
    
    normalized_features = (features_matrix - min_values) ./ range_values;
end

% Entropy function
function H = entropy(labels)
    % Get the unique values and their probabilities
    unique_labels = unique(labels);
    p = zeros(size(unique_labels));
    
    for i = 1:length(unique_labels)
        p(i) = sum(labels == unique_labels(i)) / length(labels);
    end
    
    % Calculate entropy
    H = -sum(p .* log2(p + eps));
end

function selected_features = select_top_features(features_matrix, labels, k)
    info_gain = calculate_information_gain(features_matrix, labels);
    [~, indices] = sort(info_gain, 'descend');
    selected_features = indices(1:k);
end
