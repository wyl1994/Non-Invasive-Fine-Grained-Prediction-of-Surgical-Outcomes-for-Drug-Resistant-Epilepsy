clc;
clear;
close all;

%% load features matrix and corresponding labels
load('encoded_features.mat');
load('feature_nettopo.mat')
% % find features within EZs (feature's name including the string "_eze_")
% index_eze = [];
% feature_name_eze = cell(0);
% for i = 1:numel(feature_name)
%     if contains(feature_name{i},'_eze') && ~contains(feature_name{i}, '_kden')
%         index_eze = [index_eze, i];
%         feature_name_eze = [feature_name_eze; feature_name{i}];
%     end
% end
% 
% features_eze = features_matrix(:, index_eze);

% feature = features_eze;
% feature = features_matrix;
feature = encoded_features;

labels = Engel_label;


%% machine learning classification
group_num = 4; % the number of types of surgical outcomes
n = 30; % n:the number of features to be selected
rng(27); % random seed

% 5-fold cross validation
k = 5;
cv = cvpartition(labels, 'KFold', k);

% initialize the confusion matrix for each model
confMat_train_svm = zeros(4, 4);
confMat_test_svm = zeros(4, 4);
confMat_train_rf = zeros(4, 4); 
confMat_test_rf = zeros(4, 4);
confMat_train_ada = zeros(4, 4); 
confMat_test_ada = zeros(4, 4);
confMat_train = zeros(4, 4);
confMat_test = zeros(4, 4);

for fold = 1:k
    train_idx = training(cv, fold);
    test_idx = test(cv, fold);
    
    train_set = feature(train_idx, :);
    train_label = labels(train_idx);
    test_set = feature(test_idx, :);
    test_label = labels(test_idx);
    
    % feature selection
    % initialize the vector of P-value
    p_values = zeros(size(train_set,2), 1); % 30 features, each with a P-value
    eff_size = zeros(size(train_set,2), 1);
    for i = 1:size(train_set,2)
        feature_data = train_set(:, i); % feature No.i
    
        [p,tbl,~] = kruskalwallis(feature_data, train_label,'off'); 
    
        p_values(i) = p;
        H = tbl(2,5);
        eff_size(i) = (double(H{1}) - group_num + 1)/length(feature_data) - group_num;
    end
    [eff_sort, idx] = sort(eff_size,'descend'); 
    idx_select = idx(1:n);
    feature_select = train_set(:, idx_select);
    test_set = test_set(:, idx_select);

    % random oversampling
    [train_set_resampled, train_label_resampled] = random_oversampling(feature_select, train_label, 0.001);
    feature_select = train_set_resampled;
    train_label = train_label_resampled;
    
    % SVM
    template = templateSVM(...
        'KernelFunction', 'polynomial', ...
        'PolynomialOrder', 4, ...
        'KernelScale', 'auto', ...
        'BoxConstraint', 0.1, ...
        'Standardize', true);
    
    model_svm = fitcecoc(feature_select, train_label, 'Learners', template);
    
    predictedLabels_train_svm = predict(model_svm, feature_select);
    confMat_train_svm = confMat_train_svm + get_confusion_matrix(train_label, predictedLabels_train_svm);
    
    predictedLabels_test_svm = predict(model_svm, test_set);
    confMat_test_svm = confMat_test_svm + get_confusion_matrix(test_label, predictedLabels_test_svm);
    
    % Random Forest
    numTrees = 30;
    B = TreeBagger(numTrees, feature_select, train_label, 'Method', 'classification');
    
    predictedLabels_train_rf = predict(B, feature_select);
    predictedLabels_train_rf = str2double(predictedLabels_train_rf);
    confMat_train_rf = confMat_train_rf + get_confusion_matrix(train_label, predictedLabels_train_rf);
    
    predictedLabels_test_rf = predict(B, test_set);
    predictedLabels_test_rf = str2double(predictedLabels_test_rf);
    confMat_test_rf = confMat_test_rf + get_confusion_matrix(test_label, predictedLabels_test_rf);
    
    % Adaboost
    learners = 'discriminant';
    method = 'AdaBoostM2';
    model_ada = fitcensemble(feature_select, train_label, ...
        'Method', method, 'NumLearningCycles', numTrees, ...
        'Learners', learners);
    
    predictedLabels_train_ada = predict(model_ada, feature_select);
    confMat_train_ada = confMat_train_ada + get_confusion_matrix(train_label, predictedLabels_train_ada);
    
    predictedLabels_test_ada = predict(model_ada, test_set);
    confMat_test_ada = confMat_test_ada + get_confusion_matrix(test_label, predictedLabels_test_ada);

    % voting integration
    predictedLabels_train = [predictedLabels_train_svm, predictedLabels_train_rf, predictedLabels_train_ada]';
    predictedLabels_train = mode(predictedLabels_train);
    confMat_train = confMat_train + get_confusion_matrix(train_label, predictedLabels_train');
    predictedLabels_test = [predictedLabels_test_svm, predictedLabels_test_rf, predictedLabels_test_ada]';
    predictedLabels_test = mode(predictedLabels_test);
    confMat_test = confMat_test + get_confusion_matrix(test_label, predictedLabels_test');
end

% metric calculation
[overall_metrics_train_svm, class_metrics_train_svm] = calculate_metrics_multiclass(confMat_train_svm);
[overall_metrics_test_svm, class_metrics_test_svm] = calculate_metrics_multiclass(confMat_test_svm);

[overall_metrics_train_rf, class_metrics_train_rf] = calculate_metrics_multiclass(confMat_train_rf);
[overall_metrics_test_rf, class_metrics_test_rf] = calculate_metrics_multiclass(confMat_test_rf);

[overall_metrics_train_ada, class_metrics_train_ada] = calculate_metrics_multiclass(confMat_train_ada);
[overall_metrics_test_ada, class_metrics_test_ada] = calculate_metrics_multiclass(confMat_test_ada);

[overall_metrics_train, class_metrics_train] = calculate_metrics_multiclass(confMat_train);
[overall_metrics_test, class_metrics_test] = calculate_metrics_multiclass(confMat_test);
% showing the results
classifiers = {'SVM', 'Random Forest', 'Adaboost', 'Voting Integration'};
metrics_names = {'Accuracy', 'PPV', 'NPV', 'Sensitivity', 'Specificity', 'F1-score'};
class_labels = {'Class 1', 'Class 2', 'Class 3', 'Class 4'};

overall_metrics_train_all = {overall_metrics_train_svm, overall_metrics_train_rf, overall_metrics_train_ada, overall_metrics_train};
overall_metrics_test_all = {overall_metrics_test_svm, overall_metrics_test_rf, overall_metrics_test_ada, overall_metrics_test};

class_metrics_train_all = {class_metrics_train_svm, class_metrics_train_rf, class_metrics_train_ada, class_metrics_train};
class_metrics_test_all = {class_metrics_test_svm, class_metrics_test_rf, class_metrics_test_ada, class_metrics_test};

for i = 1:4
    fprintf('%s Average Training Metrics:\n', classifiers{i});
    for j = 1:6
        fprintf('%s: %.2f%%\n', metrics_names{j}, overall_metrics_train_all{i}(j) * 100);
    end
    for c = 1:4
        fprintf('%s Training Metrics for %s:\n', classifiers{i}, class_labels{c});
        for j = 2:6
            fprintf('%s: %.2f%%\n', metrics_names{j}, class_metrics_train_all{i}(c, j-1) * 100);
        end
    end
    fprintf('%s Average Testing Metrics:\n', classifiers{i});
    for j = 1:6
        fprintf('%s: %.2f%%\n', metrics_names{j}, overall_metrics_test_all{i}(j) * 100);
    end
    for c = 1:4
        fprintf('%s Testing Metrics for %s:\n', classifiers{i}, class_labels{c});
        for j = 2:6
            fprintf('%s: %.2f%%\n', metrics_names{j}, class_metrics_test_all{i}(c, j-1) * 100);
        end
    end
end



function [overall_metrics, class_metrics] = calculate_metrics_multiclass(totalConfMat)
    % sample size
    totalSamples = sum(totalConfMat(:));

    % accuracy
    accuracy = sum(diag(totalConfMat)) / totalSamples;

    % initialization
    num_classes = size(totalConfMat, 1);
    PPV = zeros(1, num_classes);
    NPV = zeros(1, num_classes);
    Sensitivity = zeros(1, num_classes);
    Specificity = zeros(1, num_classes);
    F1 = zeros(1, num_classes);

    for i = 1:num_classes
        TP = totalConfMat(i, i);
        FP = sum(totalConfMat(:, i)) - TP;
        FN = sum(totalConfMat(i, :)) - TP;
        TN = totalSamples - TP - FP - FN;

        % calculate the metrics
        PPV(i) = TP / (TP + FP);
        NPV(i) = TN / (TN + FN);
        Sensitivity(i) = TP / (TP + FN);
        Specificity(i) = TN / (TN + FP);
        F1(i) = 2 * TP / (2 * TP + FP + FN);
    end

    % calculate the average metrics
    avg_PPV = mean(PPV, 'omitnan');
    avg_NPV = mean(NPV, 'omitnan');
    avg_Sensitivity = mean(Sensitivity, 'omitnan');
    avg_Specificity = mean(Specificity, 'omitnan');
    avg_F1 = mean(F1, 'omitnan');

    overall_metrics = [accuracy, avg_PPV, avg_NPV, avg_Sensitivity, avg_Specificity, avg_F1];
    class_metrics = [PPV; NPV; Sensitivity; Specificity; F1]';
end

function confMat = get_confusion_matrix(true_labels, predicted_labels)
    % change the label to categorical type
    true_labels = categorical(true_labels);
    predicted_labels = categorical(predicted_labels);

    % calculate the confusion matrix
    [confMat, ~] = confusionmat(true_labels, predicted_labels);
end

function [X_resampled, Y_resampled] = random_oversampling(X, Y, noise_level)
    % random oversampling with added noise to ensure the same size of each class
    % X: feature matrix
    % Y: label vector
    % noise_level: the magnitude of noise to add (e.g., 0.01 for 1% noise)
    
    classes = unique(Y);
    max_samples = max(histcounts(Y));
    
    X_resampled = [];
    Y_resampled = [];
    
    for i = 1:length(classes)
        classIdx = (Y == classes(i));
        X_class = X(classIdx, :);
        Y_class = Y(classIdx);
        
        num_to_add = max_samples - sum(classIdx);
        
        if num_to_add > 0
            idx = randsample(size(X_class, 1), num_to_add, true);
            X_new = X_class(idx, :);
            
            % Add random noise to oversampled data
            noise = noise_level * randn(size(X_new));
            X_new_with_noise = X_new + noise;
            
            X_resampled = [X_resampled; X_class; X_new_with_noise];
            Y_resampled = [Y_resampled; Y_class; Y_class(idx)];
        else
            X_resampled = [X_resampled; X_class];
            Y_resampled = [Y_resampled; Y_class];
        end
    end
    
    % Shuffling the data
    rand_idx = randperm(size(X_resampled, 1));
    X_resampled = X_resampled(rand_idx, :);
    Y_resampled = Y_resampled(rand_idx);
end