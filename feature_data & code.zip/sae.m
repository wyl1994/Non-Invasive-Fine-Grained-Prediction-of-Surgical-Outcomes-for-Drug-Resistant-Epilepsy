function encoded_features = sae(features_matrix,hiddenSize, sparsityRegularization, sparsityProportion, lambda)
    % Define the size of the hidden layer (dimensionality of the reduced space)
    % hiddenSize = 20; % Example: reduce to 20 dimensions

    % Define the parameters for the Sparse Autoencoder
    % sparsityRegularization = 1; % Weight of sparsity penalty term
    % sparsityProportion = 0.05; % Desired proportion of active neurons
    % lambda = 0.0001; % Weight decay regularization

    % Train the Sparse Autoencoder using the built-in function
    autoenc = trainAutoencoder(features_matrix', hiddenSize, ...
        'MaxEpochs', 3000, ... % Number of training epochs
        'L2WeightRegularization', lambda, ...
        'SparsityRegularization', sparsityRegularization, ...
        'SparsityProportion', sparsityProportion, ...
        'ScaleData', false);

    % Encode the input data to the reduced dimensional space
    encoded_features = encode(autoenc, features_matrix');
    encoded_features = encoded_features';
end